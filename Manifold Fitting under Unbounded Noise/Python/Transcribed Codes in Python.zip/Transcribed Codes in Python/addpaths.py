import sys

sys.path.append('algo')
sys.path.append('utils')
sys.path.append('simulations')
sys.path.append('out')
sys.path.append('figures')